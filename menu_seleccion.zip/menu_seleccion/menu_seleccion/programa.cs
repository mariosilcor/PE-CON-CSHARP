﻿using System;
namespace menu_seleccion
{
	class programa
	{
		static void Main(string[] args)
		{
			menu inicio = new menu();
		}
	}
}

