﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Recursividad2
{
    public class Recursividad
    {

        void imprimir(int x) {
        if (x>0) {
            Console.WriteLine(x);
            imprimir(x-1);
             }    
         }

        static void Main(string[] ar)
        {
            Recursividad re = new Recursividad();
            re.imprimir(5);
            Console.ReadKey();
        }
    }
}